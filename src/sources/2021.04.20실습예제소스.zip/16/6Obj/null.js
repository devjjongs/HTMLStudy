console.log(null);
console.log(typeof(null));