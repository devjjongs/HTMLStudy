// 변수를 선언합니다.
let string = '감자,고구마,바나나,사과';
// 문자열을 쉼표로 자르고 출력합니다.
let array = string.split(',');
console.log(array);