let stringA = '과자|1500원';
console.log(stringA.split('|'));

let stringB = new String('과자|1500원');
console.log(stringB.split('|'));